=== Nostrly ===
Contributors: robwoodgate
Tags: nostr
Requires at least: 5.5
Tested up to: 6.6
Stable tag: trunk

Enables login with Nostr identity, and syncs profile data.

== Description ==
Powers the Cogmentis Nostrly SaaS

== Installation ==

1. Upload `nostrly` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu
3. Go to Settings > Nostrly to configure relay settings
